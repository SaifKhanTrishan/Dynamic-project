<?php

use Illuminate\Foundation\Application;
use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true)); // Define the start time of the application

// Determine if the application is in maintenance mode...
if (file_exists($maintenance = __DIR__.'/../storage/framework/maintenance.php')) { // Check for maintenance mode file
require $maintenance; // Require the maintenance file if it exists
}

// Register the Composer autoloader...
require __DIR__.'/../vendor/autoload.php'; // Include the Composer autoloader

// Bootstrap Laravel and handle the request...
/** @var Application $app */
$app = require_once __DIR__.'/../bootstrap/app.php'; // Bootstrap the Laravel application

$app->handleRequest(Request::capture()); // Handle the incoming HTTP request

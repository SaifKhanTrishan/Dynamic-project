function suggest(nutrient, direction) {
    //function to fetch recipe suggestions based on nutrient and direction
    fetch(`/recipes/suggest?nutrient=${nutrient}&direction=${direction}`) //make a GET request to the suggestions endpoint with nutrient and direction as query parameters
        .then((res) => res.text()) //convert the response to text
        .then(
            (html) => (document.getElementById("suggestions").innerHTML = html) //update the inner HTML of the suggestions div with the received HTML
        );
}

<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class RecipeFactory extends Factory
{
    public function definition(): array
    {
        return [
            'name' => $this->faker->word(), //Generate a random word for the recipe name
            'description' => $this->faker->sentence(), //Generate a random sentence for the recipe description
        'calories' => $this->faker->numberBetween(200, 800), //Generate a random number between 200 and 800 for calories
            'protein' => $this->faker->numberBetween(10, 50),//Generate a random number between 10 and 50 for protein
            'carbs' => $this->faker->numberBetween(20, 100),//Generate a random number between 20 and 100 for carbs
        'fat' => $this->faker->numberBetween(5, 30), // Generate a random number between 5 and 30 for fat
            'fiber' => $this->faker->numberBetween(2, 15), //Generate a random number between 2 and 15 for fiber
        'carbon_footprint' => $this->faker->randomFloat(2, 0.1, 5.0), //Generate a random float between 0.1 and 5.0 for carbon footprint
        ];
    }
}

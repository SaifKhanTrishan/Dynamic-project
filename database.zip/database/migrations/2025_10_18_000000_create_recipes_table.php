<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {  //class extending Migration
    public function up() //method to create the recipes table
    {
        Schema::create('recipes', function (Blueprint $table) { //create recipes table with the following columns
            $table->id();
            $table->string('name');
            $table->text('description')->nullable();
            $table->integer('calories');
            $table->integer('protein');
            $table->integer('carbs');
            $table->integer('fat');
            $table->integer('fiber');
            $table->float('carbon_footprint');
            $table->timestamps();
        });
    }
    public function down() //method to drop the recipes table
    {
        Schema::dropIfExists('recipes');//drop the recipes table if it exists
    }
};

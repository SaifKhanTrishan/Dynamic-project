<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration { //class extending Migration
    public function up() {
        Schema::create('goals', function (Blueprint $table) { //create goals table with the following columns
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('nutrient');
            $table->enum('direction', ['up', 'down']);
            $table->float('target_value');
            $table->timestamps();
        });
    }

    public function down() {
        Schema::dropIfExists('goals'); //drop the goals table if it exists
    }
};

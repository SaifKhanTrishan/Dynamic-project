<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration { //class extending Migration
    public function up() {
        Schema::create('meal_plans', function (Blueprint $table) { //create meal_plans table with the following columns
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('recipe_id')->constrained()->cascadeOnDelete();
            $table->date('date');
            $table->integer('servings')->default(1);
            $table->timestamps();
        });
    }

    public function down() {
        Schema::dropIfExists('meal_plans'); //drop the meal_plans table if it exists
    }
};

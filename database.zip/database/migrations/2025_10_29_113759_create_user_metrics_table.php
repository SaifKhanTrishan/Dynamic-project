<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration { //class extending Migration
    public function up() {
        Schema::create('user_metrics', function (Blueprint $table) { //create user_metrics table with the following columns
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->float('weight')->nullable();
            $table->string('blood_pressure')->nullable();
            $table->timestamp('recorded_at')->useCurrent();
            $table->timestamps();
        });
    }

};


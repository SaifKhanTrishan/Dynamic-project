<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration { //class extending Migration
    public function up() {
        Schema::create('users', function (Blueprint $table) { //create users table with the following columns
            $table->id(); // BIGINT UNSIGNED by default
            $table->string('name');
            $table->string('email')->unique();
            $table->string('password');
            $table->timestamps();
        });
    }

    public function down() {
        Schema::dropIfExists('users'); //drop the users table if it exists
    }
};

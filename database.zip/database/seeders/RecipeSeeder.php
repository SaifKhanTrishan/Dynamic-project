<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Recipe;

class RecipeSeeder extends Seeder // class seeder autpmatically inserts some recipes into the recipes table
{
    public function run() // run method to insert recipes
    {
        Recipe::insert([
            ['name'=>'Grilled Chicken Salad','description'=>'Chicken+Veg','calories'=>350,'protein'=>30,'carbs'=>10,'fat'=>20,'fiber'=>5,'carbon_footprint'=>2.5,'created_at'=>now(),'updated_at'=>now()],
            ['name'=>'Veggie Stir Fry','description'=>'Mixed Veg','calories'=>250,'protein'=>10,'carbs'=>35,'fat'=>5,'fiber'=>8,'carbon_footprint'=>1.2,'created_at'=>now(),'updated_at'=>now()],
            ['name'=>'Oatmeal with Fruits','description'=>'Oats+Banana','calories'=>200,'protein'=>8,'carbs'=>40,'fat'=>4,'fiber'=>6,'carbon_footprint'=>0.8,'created_at'=>now(),'updated_at'=>now()]
        ]);
    }
}

<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder // main database seeder class
{
    public function run() // run method to call other seeders
    {
        $this->call([ // call the following seeders
            UserMetricsSeeder::class,
            GoalsTableSeeder::class,   
            MealPlansTableSeeder::class,
            RecipesTableSeeder::class,  
            RecipeSeeder::class,
        ]);
    }
}

<!-- resources/views/recipes/suggestions.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Recipe Suggestions</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #1CA9C9;
            color: #fff;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
        }

        .header-banner {
            background: linear-gradient(135deg, #1CA9C9 0%, #0077B6 100%);
            padding: 30px;
            border-radius: 8px;
            margin-bottom: 30px;
            text-align: center;
        }

        .header-banner h1 {
            margin: 0;
            font-size: 32px;
            font-weight: 700;
        }

        .header-banner p {
            margin: 10px 0 0 0;
            font-size: 14px;
            opacity: 0.9;
        }

        .nav-section {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 30px;
            text-align: center;
        }

        .nav-section a {
            display: inline-block;
            background-color: #0077B6;
            color: #fff;
            padding: 12px 20px;
            margin: 8px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 15px;
            font-weight: 500;
            transition: all 0.2s ease;
        }

        .nav-section a:hover {
            background-color: #023E8A;
            transform: translateY(-2px);
        }

        h2 {
            font-size: 24px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin: 30px 0 20px 0;
            text-align: center;
        }

        .suggestions-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .suggestion-item {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 20px;
            margin-bottom: 15px;
            border-radius: 8px;
            border-left: 4px solid rgba(255, 255, 255, 0.3);
            transition: all 0.2s ease;
        }

        .suggestion-item:hover {
            background-color: rgba(255, 255, 255, 0.15);
            transform: translateX(5px);
        }

        .recipe-name {
            font-size: 18px;
            font-weight: 700;
            margin: 0 0 10px 0;
        }

        .nutrition-details {
            font-size: 13px;
            opacity: 0.9;
            margin-bottom: 15px;
            line-height: 1.6;
        }

        .nutrition-details strong {
            font-weight: 600;
        }

        .add-form {
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }

        .add-form input {
            padding: 10px;
            border: none;
            border-radius: 4px;
            font-size: 13px;
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
        }

        .add-form input::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }

        .add-form input[type="date"] {
            min-width: 150px;
        }

        .add-form input[type="number"] {
            width: 80px;
        }

        .add-form button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            font-size: 13px;
            transition: background-color 0.2s;
        }

        .add-form button:hover {
            background-color: #218838;
        }

        .no-results {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 30px;
            text-align: center;
            border-radius: 8px;
            margin: 20px 0;
        }

        @media (max-width: 768px) {
            .add-form {
                flex-direction: column;
            }

            .add-form input,
            .add-form button {
                width: 100%;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <!-- Header -->
    <div class="header-banner">
        <h1>🔍 Filtered Recipes</h1>
        <p>Recipes matching your nutritional criteria</p>
    </div>

    <!-- Navigation -->
   
    <!-- Suggestions Section -->
    <h2>Suggested Recipes</h2>

    <?php if($recipes->count() > 0): ?>
        <ul class="suggestions-list">
            <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="suggestion-item">
                    <p class="recipe-name"><?php echo e($recipe->name); ?></p>
                    
                    <div class="nutrition-details">
                        <strong>Calories:</strong> <?php echo e($recipe->calories); ?> |
                        <strong>Protein:</strong> <?php echo e($recipe->protein); ?>g |
                        <strong>Carbs:</strong> <?php echo e($recipe->carbs); ?>g |
                        <strong>Fat:</strong> <?php echo e($recipe->fat); ?>g |
                        <strong>Fiber:</strong> <?php echo e($recipe->fiber); ?>g |
                        <strong>Carbon:</strong> <?php echo e($recipe->carbon_footprint); ?> kg CO₂
                    </div>

                    <form action="<?php echo e(route('mealplans.store')); ?>" method="POST" class="add-form">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="recipe_id" value="<?php echo e($recipe->id); ?>">
                        <input type="date" name="date" required>
                        <input type="number" name="servings" value="1" min="1" max="10" placeholder="Servings">
                        <button type="submit">Add to Plan →</button>
                    </form>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php else: ?>
        <div class="no-results">
            <p><strong>No recipes found matching your criteria</strong></p>
            <p style="font-size: 13px;">Try adjusting your filters or create more recipes.</p>
        </div>
    <?php endif; ?>
</div>

</body>
</html><?php /**PATH D:\xampp\htdocs\laravel12\mealplanner\resources\views/recipes/suggestions.blade.php ENDPATH**/ ?>
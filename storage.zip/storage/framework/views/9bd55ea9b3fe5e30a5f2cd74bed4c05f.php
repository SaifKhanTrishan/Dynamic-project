<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Goals</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #1CA9C9;
            color: #fff;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
        }

        .header {
            background: linear-gradient(135deg, #1CA9C9 0%, #0077B6 100%);
            padding: 30px;
            border-radius: 8px;
            margin-bottom: 30px;
        }

        .header h1 {
            margin: 0;
            font-size: 28px;
        }

        .nav-links {
            margin-bottom: 20px;
        }

        .nav-links a {
            display: inline-block;
            background-color: #0077B6;
            color: white;
            padding: 10px 20px;
            margin: 5px;
            border-radius: 6px;
            text-decoration: none;
        }

        .nav-links a:hover {
            background-color: #023E8A;
        }

        .btn {
            display: inline-block;
            background-color: #28a745;
            color: white;
            padding: 12px 24px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            margin-bottom: 20px;
        }

        .btn:hover {
            background-color: #218838;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            color: #333;
            border-radius: 8px;
            overflow: hidden;
        }

        th {
            background-color: #0077B6;
            color: white;
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }

        td {
            padding: 12px 15px;
            border-bottom: 1px solid #e0e0e0;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        .direction-up {
            background-color: #d4edda;
            color: #155724;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
        }

        .direction-down {
            background-color: #f8d7da;
            color: #721c24;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
        }

        .delete-btn {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
        }

        .delete-btn:hover {
            background-color: #c82333;
        }

        .empty-message {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 30px;
            text-align: center;
            border-radius: 8px;
            margin: 20px 0;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1>📋 My Nutritional Goals</h1>
        <p>Set and track your nutritional targets</p>
    </div>

    <div class="nav-links">
        <a href="/">← Back to Recipes</a>
        <a href="/recipes/smart-suggest">💡 Get Suggestions</a>
        <a href="/mealplans">📅 My Meals</a>
    </div>

    <a href="/goals/create" class="btn">➕ Create New Goal</a>

    <?php if($goals->count() > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Nutrient</th>
                    <th>Direction</th>
                    <th>Target Value</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><strong><?php echo e(ucfirst(str_replace('_', ' ', $goal->nutrient))); ?></strong></td>
                        <td>
                            <?php if($goal->direction === 'up'): ?>
                                <span class="direction-up">⬆️ Increase</span>
                            <?php else: ?>
                                <span class="direction-down">⬇️ Decrease</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e(number_format($goal->target_value, 0)); ?></td>
                        <td>
                            <form action="/goals/<?php echo e($goal->id); ?>" method="POST" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="delete-btn" onclick="return confirm('Delete this goal?');">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="empty-message">
            <p><strong>No goals yet!</strong></p>
            <p>Create your first goal to get started with personalized recipe suggestions.</p>
            <a href="/goals/create" class="btn" style="margin-top: 15px;">Create Goal</a>
        </div>
    <?php endif; ?>

</div>

</body>
</html><?php /**PATH D:\xampp\htdocs\laravel12\mealplanner\resources\views/goals/index.blade.php ENDPATH**/ ?>
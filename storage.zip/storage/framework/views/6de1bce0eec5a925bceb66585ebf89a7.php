<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Goal</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #1CA9C9;
            color: #fff;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
        }

        .header {
            background: linear-gradient(135deg, #1CA9C9 0%, #0077B6 100%);
            padding: 30px;
            border-radius: 8px;
            margin-bottom: 30px;
        }

        .header h1 {
            margin: 0;
            font-size: 28px;
        }

        .form-container {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            color: #333;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #333;
        }

        input, select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            box-sizing: border-box;
        }

        input:focus, select:focus {
            outline: none;
            border-color: #0077B6;
            box-shadow: 0 0 5px rgba(0, 119, 182, 0.3);
        }

        .button-group {
            display: flex;
            gap: 10px;
            margin-top: 30px;
        }

        button {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
        }

        .btn-submit {
            background-color: #28a745;
            color: white;
        }

        .btn-submit:hover {
            background-color: #218838;
        }

        .btn-cancel {
            background-color: #6c757d;
            color: white;
        }

        .btn-cancel:hover {
            background-color: #5a6268;
        }

        .info-text {
            background-color: #e7f3ff;
            color: #0077B6;
            padding: 15px;
            border-radius: 6px;
            font-size: 14px;
            margin-top: 20px;
        }

        .error {
            color: #dc3545;
            font-size: 12px;
            margin-top: 5px;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1>➕ Create New Goal</h1>
        <p>Set a nutritional target to track</p>
    </div>

    <div class="form-container">
        <form action="/goals" method="POST">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="nutrient">Nutrient *</label>
                <select name="nutrient" id="nutrient" required>
                    <option value="">-- Select Nutrient --</option>
                    <option value="protein">Protein (g)</option>
                    <option value="carbs">Carbohydrates (g)</option>
                    <option value="fat">Fat (g)</option>
                    <option value="fiber">Fiber (g)</option>
                    <option value="calories">Calories (kcal)</option>
                    <option value="carbon_footprint">Carbon Footprint (kg CO2)</option>
                </select>
                <?php $__errorArgs = ['nutrient'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="direction">Direction *</label>
                <select name="direction" id="direction" required>
                    <option value="">-- Select Direction --</option>
                    <option value="up">⬆️ Increase (reach or exceed target)</option>
                    <option value="down">⬇️ Decrease (stay below target)</option>
                </select>
                <?php $__errorArgs = ['direction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="target_value">Target Value *</label>
                <input type="number" name="target_value" id="target_value" step="0.01" required 
                       placeholder="e.g., 100 for 100g protein">
                <?php $__errorArgs = ['target_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="info-text">
                <strong>Examples:</strong>
                <ul style="margin: 10px 0; padding-left: 20px;">
                    <li>Protein: ⬆️ 100g (want more)</li>
                    <li>Calories: ⬇️ 2000 kcal (want less)</li>
                    <li>Fiber: ⬆️ 30g (want more)</li>
                    <li>Carbon: ⬇️ 5 kg (want eco-friendly)</li>
                </ul>
            </div>

            <div class="button-group">
                <button type="submit" class="btn-submit">Create Goal</button>
                <a href="/goals" class="btn-cancel" style="text-decoration: none; display: flex; align-items: center; justify-content: center;">Cancel</a>
            </div>
        </form>
    </div>
</div>

</body>
</html><?php /**PATH D:\xampp\htdocs\laravel12\mealplanner\resources\views/goals/create.blade.php ENDPATH**/ ?>
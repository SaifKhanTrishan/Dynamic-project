<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Goal extends Model // newly created Goal model
{
    use HasFactory; //use HasFactory trait for factory methods
    protected $fillable = ['user_id','nutrient','direction','target_value']; //Get the fillable atrributes by specifying an array of attribute names that can be mass assigned.

    public function user() //define relationship to User model
    {
        return $this->belongsTo(User::class); //Each goal belongs to a single user
    }
}

<?php
// app/Models/UserMetric.php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserMetric extends Model
{
    use HasFactory;
    
    protected $fillable = ['user_id', 'weight', 'blood_pressure', 'recorded_at'];
    
    // Add this: Cast recorded_at to Carbon date
    protected $casts = [
        'recorded_at' => 'date',
    ];
    
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
?>
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Recipe extends Model
{
    use HasFactory;
    protected $fillable = ['name','description','calories','protein','carbs','fat','fiber','carbon_footprint']; //specify the attributes that are mass to be assigned from the database(The database columns that can be filled using mass assignment)

    public function mealPlans() //define relationship to MealPlan model
    {
        return $this->hasMany(MealPlan::class); //A recipe can have multiple meal plans associated with it
    }
}

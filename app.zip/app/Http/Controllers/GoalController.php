<?php
// app/Http/Controllers/GoalController.php - COMPLETE VERSION

namespace App\Http\Controllers;

use App\Models\Goal;
use Illuminate\Http\Request;

class GoalController extends Controller
{
    // Show all goals
    public function index()
    {
        $goals = Goal::all(); // Get all goals from the database
        return view('goals.index', compact('goals')); // Return the goals.index view
    }

    // Show create goal form
    public function create()
    {
        return view('goals.create'); // Return the goals.create view with the form
    }

    // Store new goal in database
    public function store(Request $request)
    {
        // Validate the request
        $validated = $request->validate([
            'nutrient' => 'required|in:protein,carbs,fat,fiber,calories,carbon_footprint',
            'direction' => 'required|in:up,down',
            'target_value' => 'required|numeric|min:0',
        ]);

        // Add user_id (hardcoded as 1 for now - replace with auth()->id() when auth is implemented)
        $validated['user_id'] = 1;

        // Create a new goal with the validated data
        Goal::create($validated);

        return redirect()->route('goals.index')->with('success', 'Goal created successfully!');
    }

    // Show a specific goal (optional)
    public function show(Goal $goal) // Route model binding
    {
        return view('goals.show', compact('goal')); // Return the goals.show view
    }

    // Show edit form (optional - not implemented yet)
    public function edit(Goal $goal) // This function is optional
    {
        return view('goals.edit', compact('goal'));
    }

    // Update goal (optional - not implemented yet)
    public function update(Request $request, Goal $goal)
    {
        $validated = $request->validate([
            'nutrient' => 'required|in:protein,carbs,fat,fiber,calories,carbon_footprint',
            'direction' => 'required|in:up,down',
            'target_value' => 'required|numeric|min:0',
        ]);

        $goal->update($validated);

        return redirect()->route('goals.index')->with('success', 'Goal updated successfully!');
    }

    // Delete a goal
    public function destroy(Goal $goal)
    {
        $goal->delete();
        return redirect()->route('goals.index')->with('success', 'Goal deleted successfully!');
    }
}
?>
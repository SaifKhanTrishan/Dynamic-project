<?php
// app/Http/Controllers/UserMetricController.php - COMPLETE VERSION

namespace App\Http\Controllers;

use App\Models\UserMetric;
use Illuminate\Http\Request;

class UserMetricController extends Controller
{
    // Show all user metrics
    public function index()
    {
        $metrics = UserMetric::where('user_id', 1) // Get metrics for current user (hardcoded as 1)
                              ->orderBy('recorded_at', 'desc') // Most recent first
                              ->paginate(20); // Show 20 per page
        return view('usermetrics.index', compact('metrics'));
    }

    // Show create metric form
    public function create()
    {
        return view('usermetrics.create'); // Return the usermetrics.create view with the form
    }

    // Store new metric in database
    public function store(Request $request)
    {
        // Validate the request
        $validated = $request->validate([
            'recorded_at' => 'required|date',
            'weight' => 'nullable|numeric|min:0',
            'blood_pressure' => 'nullable|string',
        ]);

        // Add user_id (hardcoded as 1 for now - replace with auth()->id())
        $validated['user_id'] = 1;

        // Create a new user metric with the validated data
        UserMetric::create($validated);

        return redirect()->route('usermetrics.index')->with('success', 'Biometric data recorded successfully!');
    }

    // Show a specific metric (optional)
    public function show(UserMetric $metric)
    {
        return view('usermetrics.show', compact('metric'));
    }

    // Show edit form (optional - not implemented)
    public function edit(UserMetric $metric)
    {
        return view('usermetrics.edit', compact('metric'));
    }

    // Update metric (optional - not implemented)
    public function update(Request $request, UserMetric $metric)
    {
        $validated = $request->validate([
            'recorded_at' => 'required|date',
            'weight' => 'nullable|numeric|min:0',
            'blood_pressure' => 'nullable|string',
        ]);

        $metric->update($validated);

        return redirect()->route('usermetrics.index')->with('success', 'Biometric data updated successfully!');
    }

    // Delete a metric
    public function destroy(UserMetric $usermetric)
    {
        $usermetric->delete();
        return redirect()->route('usermetrics.index')->with('success', 'Metric deleted successfully!');
    }
}
?>
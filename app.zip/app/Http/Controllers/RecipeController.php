<?php
// app/Http/Controllers/RecipeController.php - FIXED VERSION

namespace App\Http\Controllers;

use App\Models\Recipe;
use App\Models\Goal;
use App\Models\MealPlan;
use Illuminate\Http\Request;

class RecipeController extends Controller
{
    public function index() // method to list all recipes
    {
        $recipes = Recipe::all(); // get all recipes from the database
        return view('index', compact('recipes')); // return the index view with the recipes data
    }

    public function suggest(Request $request) // method to suggest recipes based on nutrient criteria
    {
        $recipes = Recipe::query() // start a new query on the Recipe model
            ->when($request->direction=='up', fn($q)=>$q->orderByDesc($request->nutrient)) // order by nutrient descending if direction is 'up'
            ->when($request->direction=='down', fn($q)=>$q->orderBy($request->nutrient)) // order by nutrient ascending if direction is 'down'
            ->take(5) // limit the results to 5 recipes
            ->get(); // execute the query and get the results

        return view('recipes.suggestions', compact('recipes')); // return the recipes.suggestions view
    }

    // NEW METHOD: Get smart suggestions based on user goals
    public function smartSuggest()
    {
        $user_id = 1; // Hardcoded for now - replace with auth()->id() when auth is implemented
        
        // Get all active goals for the user
        $goals = Goal::where('user_id', $user_id)->get();

        if ($goals->isEmpty()) {
            return view('recipes.smartSuggest', [
                'suggestions' => [],
                'message' => 'No goals set. Please create goals first to get personalized suggestions.',
                'currentTotals' => [],
                'goals' => []
            ]);
        }

        // Get today's meal plans
        $today = now()->toDateString();
        $todayMeals = MealPlan::where('user_id', $user_id)
            ->where('date', $today)
            ->with('recipe')
            ->get();

        // Calculate current daily totals
        $currentTotals = [
            'protein' => 0,
            'carbs' => 0,
            'fat' => 0,
            'fiber' => 0,
            'calories' => 0,
            'carbon_footprint' => 0,
        ];

        foreach ($todayMeals as $meal) {
            $currentTotals['protein'] += $meal->recipe->protein * $meal->servings;
            $currentTotals['carbs'] += $meal->recipe->carbs * $meal->servings;
            $currentTotals['fat'] += $meal->recipe->fat * $meal->servings;
            $currentTotals['fiber'] += $meal->recipe->fiber * $meal->servings;
            $currentTotals['calories'] += $meal->recipe->calories * $meal->servings;
            $currentTotals['carbon_footprint'] += $meal->recipe->carbon_footprint * $meal->servings;
        }

        // Get all recipes and score them
        $allRecipes = Recipe::all();
        $scoredRecipes = [];

        foreach ($allRecipes as $recipe) {
            $score = 0;
            $helps_with = []; // Track which goals this recipe helps with

            foreach ($goals as $goal) {
                $nutrient = $goal->nutrient;
                $target = $goal->target_value;
                $direction = $goal->direction;
                $current = $currentTotals[$nutrient] ?? 0;

                // Score calculation based on direction
                if ($direction === 'up') {
                    // Need to increase nutrient
                    if ($current < $target) {
                        $need = $target - $current;
                        $contribution = $recipe->{$nutrient};
                        
                        if ($contribution > 0) {
                            $score += ($contribution / $need) * 100;
                            $helps_with[] = "$nutrient (↑)";
                        }
                    }
                } else {
                    // Need to decrease nutrient (direction === 'down')
                    if ($current > $target) {
                        // Prefer recipes low in this nutrient
                        $penalty = max(0, $recipe->{$nutrient});
                        $score -= $penalty * 2;
                    } else {
                        // Already below target, keep it that way
                        
                        $mealCount = count($todayMeals) > 0 ? count($todayMeals) : 1;
                        $averageNutrient = $currentTotals[$nutrient] / $mealCount;
                        
                        if ($recipe->{$nutrient} < $averageNutrient) {
                            $score += 20; // Bonus for low values
                        }
                    }
                }
            }

            // Penalize high carbon footprint (encourage eco-friendly)
            $score -= $recipe->carbon_footprint * 5;

            if ($score > 0 || count($helps_with) > 0) {
                $scoredRecipes[] = [
                    'recipe' => $recipe,
                    'score' => max(0, $score),
                    'helps_with' => $helps_with,
                ];
            }
        }

        // Sort by score (highest first)
        usort($scoredRecipes, function ($a, $b) {
            return $b['score'] <=> $a['score'];
        });

        // Get top 8 suggestions
        $suggestions = array_slice($scoredRecipes, 0, 8);

        return view('recipes.smartSuggest', compact('suggestions', 'currentTotals', 'goals', 'today'));
    }

    // NEW METHOD: Add recipe from suggestion
    public function addFromSmartSuggest(Request $request)
    {
        $validated = $request->validate([
            'recipe_id' => 'required|exists:recipes,id',
            'date' => 'required|date',
            'servings' => 'required|integer|min:1|max:10',
        ]);

        MealPlan::create([
            'user_id' => 1, // Hardcoded for now - replace with auth()->id()
            'recipe_id' => $validated['recipe_id'],
            'date' => $validated['date'],
            'servings' => $validated['servings'],
        ]);

        return redirect()->route('recipes.smartSuggest')
                        ->with('success', 'Recipe added to your meal plan!');
    }
}
?>
<?php
// app/Http/Controllers/MealPlanController.php - COMPLETE VERSION

namespace App\Http\Controllers;

use App\Models\MealPlan;
use App\Models\Recipe;
use Illuminate\Http\Request;

class MealPlanController extends Controller
{
    // Show all meal plans for the user
    public function index()
    {
        $user_id = 1; // Hardcoded for now - replace with auth()->id() when auth is implemented
        
        // Get all meal plans with associated recipes, ordered by date
        $plans = MealPlan::where('user_id', $user_id)
                         ->with('recipe') // Eager load recipes to avoid N+1 queries
                         ->orderBy('date', 'desc') // Most recent first
                         ->get();
        
        return view('mealplans.index', compact('plans'));
    }

    // Show create meal plan form
    public function create()
    {
        $recipes = Recipe::all();
        return view('mealplans.create', compact('recipes'));
    }

    // Store new meal plan
    public function store(Request $request)
    {
        // Validate the request
        $validated = $request->validate([
            'recipe_id' => 'required|exists:recipes,id',
            'date' => 'required|date',
            'servings' => 'required|integer|min:1|max:10',
        ]);

        // Add user_id (hardcoded as 1 for now - replace with auth()->id())
        $validated['user_id'] = 1;

        // Create the meal plan
        MealPlan::create([
            'user_id' => 1,
            'recipe_id' => $validated['recipe_id'],
            'date' => $validated['date'],
            'servings' => $validated['servings'],
        ]);

        return redirect()->route('mealplans.index')->with('success', 'Meal added!');
    }

    // Show confirmation page
    public function confirmation()
    {
        return view('confirmation');
    }

    // Show a specific meal plan
    public function show(MealPlan $plan)
    {
        return view('mealplans.show', compact('plan'));
    }

    // Show edit form
    public function edit(MealPlan $plan)
    {
        $recipes = Recipe::all();
        return view('mealplans.edit', compact('plan', 'recipes'));
    }

    // Update meal plan
    public function update(Request $request, MealPlan $plan)
    {
        $validated = $request->validate([
            'recipe_id' => 'required|exists:recipes,id',
            'date' => 'required|date',
            'servings' => 'required|integer|min:1|max:10',
        ]);

        $plan->update($validated);

        return redirect()->route('mealplans.index')
                       ->with('success', 'Meal updated successfully!');
    }

    // Delete a meal plan entry
    public function destroy(MealPlan $mealplan)
    {
        $mealplan->delete();
        return redirect()->route('mealplans.index')
                       ->with('success', 'Meal removed from plan!');
    }
    

    
}
?>
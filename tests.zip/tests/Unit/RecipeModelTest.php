<?php

namespace Tests\Unit;

use Tests\TestCase;
use App\Models\Recipe;
use Illuminate\Foundation\Testing\RefreshDatabase;

class RecipeModelTest extends TestCase
{
    use RefreshDatabase;

    public function test_recipe_can_be_created()
    {
        $recipe = Recipe::create([
            'name' => 'Test Recipe',
            'description' => 'A test recipe',
            'calories' => 300,
            'protein' => 20,
            'carbs' => 40,
            'fat' => 10,
            'fiber' => 5,
            'carbon_footprint' => 2.0,
        ]);

        $this->assertDatabaseHas('recipes', [
            'name' => 'Test Recipe',
            'calories' => 300,
        ]);
    }

    public function test_recipe_fillable_attributes()
    {
        $attributes = [
            'name' => 'Fillable Test',
            'description' => 'Test description',
            'calories' => 250,
            'protein' => 15,
            'carbs' => 35,
            'fat' => 8,
            'fiber' => 4,
            'carbon_footprint' => 1.5,
        ];

        $recipe = Recipe::create($attributes);

        foreach ($attributes as $key => $value) {
            $this->assertEquals($value, $recipe->{$key});
        }
    }
}
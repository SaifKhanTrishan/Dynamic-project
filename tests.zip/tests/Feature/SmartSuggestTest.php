<?php


namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Recipe;
use App\Models\Goal;
use App\Models\User;
use App\Models\MealPlan;
use Illuminate\Foundation\Testing\RefreshDatabase;

class SmartSuggestTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp(); //parent for 
        $this->artisan('migrate:fresh'); // Ensure fresh database for each test
    }

    // Test 1: Smart suggest page loads without goals
    public function test_smart_suggest_page_loads_without_goals() // Test 1
    {
        $response = $this->get('/recipes/smart-suggest'); //response variable comes from making a GET request to the smart suggest page

        $response->assertStatus(200); // Assert that the response status is 200 (OK)
        $response->assertSee('No Goals Set'); // Assert that the response contains the text 'No Goals Set'
        $response->assertSee('Create Goals Now'); // Assert that the response contains the text 'Create Goals Now'
    }

    // Test 2: Smart suggest page loads with goals
    public function test_smart_suggest_page_loads_with_goals()
    {
        $user = User::factory()->create(['id' => 1]); // Create a user with ID 1
        
        Goal::create([ // Create a goal for the user
            'user_id' => 1, // Associate goal with user ID 1
            'nutrient' => 'protein', // Nutrient to track
            'direction' => 'up', // Direction of the goal
            'target_value' => 100, // Target value for the goal
        ]);

        $response = $this->get('/recipes/smart-suggest'); // Make a GET request to the smart suggest page
 
        $response->assertStatus(200); // Assert that the response status is 200 (OK)
    $response->assertSee("Today's Progress"); // Assert that the response contains the text "Today's Progress"
    $response->assertSee('Protein'); // Assert that the response contains the text 'Protein'
    }

    // Test 3: Recipes are scored and displayed
    public function test_recipes_are_scored_and_ranked() // Test 3
    {
        User::factory()->create(['id' => 1]); // Create a user with ID 1
        
        // Create a goal for protein
        Goal::create([
            'user_id' => 1,
            'nutrient' => 'protein',
            'direction' => 'up',
            'target_value' => 100,
        ]);

        // Create recipes with different protein content
        Recipe::create([
            'name' => 'High Protein Chicken',
            'description' => 'High protein',
            'calories' => 165,
            'protein' => 40, // High protein
            'carbs' => 0,
            'fat' => 3,
            'fiber' => 0,
            'carbon_footprint' => 1.5,
        ]);

        Recipe::create([
            'name' => 'Low Protein Salad',
            'description' => 'Low protein',
            'calories' => 100,
            'protein' => 5, // Low protein
            'carbs' => 20,
            'fat' => 1,
            'fiber' => 5,
            'carbon_footprint' => 0.5,
        ]);

        $response = $this->get('/recipes/smart-suggest');

        $response->assertStatus(200);
        $response->assertSee('High Protein Chicken');
        $response->assertSee('Low Protein Salad');
        // The high protein recipe should appear first (higher score)
        $content = $response->getContent();
        $highProteinPos = strpos($content, 'High Protein Chicken');
        $lowProteinPos = strpos($content, 'Low Protein Salad');
        $this->assertLessThan($lowProteinPos, $highProteinPos);
    }

    // Test 4: Carbon footprint penalty is applied
    public function test_carbon_footprint_reduces_score()
    {
        User::factory()->create(['id' => 1]);
        
        Goal::create([
            'user_id' => 1,
            'nutrient' => 'protein',
            'direction' => 'up',
            'target_value' => 100,
        ]);

        Recipe::create([
            'name' => 'Eco Friendly High Protein',
            'description' => 'High protein low carbon',
            'calories' => 165,
            'protein' => 40,
            'carbs' => 0,
            'fat' => 3,
            'fiber' => 0,
            'carbon_footprint' => 1.0, // Low carbon
        ]);

        Recipe::create([
            'name' => 'High Carbon High Protein',
            'description' => 'High protein high carbon',
            'calories' => 165,
            'protein' => 40,
            'carbs' => 0,
            'fat' => 3,
            'fiber' => 0,
            'carbon_footprint' => 5.0, // High carbon
        ]);

        $response = $this->get('/recipes/smart-suggest');

        $response->assertStatus(200);
        // Both recipes should be shown but eco-friendly one should rank higher
        $content = $response->getContent();
        $ecoPos = strpos($content, 'Eco Friendly High Protein');
        $carbonPos = strpos($content, 'High Carbon High Protein');
        $this->assertLessThan($carbonPos, $ecoPos);
    }

    // Test 5: Multiple goals affect scoring
    public function test_multiple_goals_affect_scoring()
    {
        User::factory()->create(['id' => 1]);
        
        Goal::create([
            'user_id' => 1,
            'nutrient' => 'protein',
            'direction' => 'up',
            'target_value' => 100,
        ]);

        Goal::create([
            'user_id' => 1,
            'nutrient' => 'fiber',
            'direction' => 'up',
            'target_value' => 30,
        ]);

        Recipe::create([
            'name' => 'Balanced Recipe',
            'description' => 'High protein and fiber',
            'calories' => 300,
            'protein' => 40,
            'carbs' => 30,
            'fat' => 5,
            'fiber' => 15,
            'carbon_footprint' => 2.0,
        ]);

        $response = $this->get('/recipes/smart-suggest');

        $response->assertStatus(200);
        $response->assertSee('Balanced Recipe');
        $response->assertSee('Helps with');
    }

    // Test 6: Recipe can be added from suggestion
    public function test_recipe_can_be_added_from_suggestion()
    {
        User::factory()->create(['id' => 1]);
        
        $recipe = Recipe::create([
            'name' => 'Test Recipe',
            'description' => 'Test',
            'calories' => 300,
            'protein' => 30,
            'carbs' => 40,
            'fat' => 10,
            'fiber' => 5,
            'carbon_footprint' => 2.0,
        ]);

        $today = now()->toDateString();

        $response = $this->post('/recipes/add-from-suggest', [
            'recipe_id' => $recipe->id,
            'date' => $today,
            'servings' => 2,
        ]);

        $response->assertRedirect('/recipes/smart-suggest');
        
        // Check if meal plan entry was created
        $this->assertDatabaseHas('meal_plans', [
            'user_id' => 1,
            'recipe_id' => $recipe->id,
            'date' => $today,
            'servings' => 2,
        ]);
    }

    // Test 7: Down direction goals penalize high nutrients
    public function test_down_direction_goal_penalizes_high_values()
    {
        User::factory()->create(['id' => 1]);
        
        // Goal to keep calories DOWN (max 500)
        Goal::create([
            'user_id' => 1,
            'nutrient' => 'calories',
            'direction' => 'down',
            'target_value' => 500,
        ]);

        Recipe::create([
            'name' => 'Low Calorie Option',
            'description' => 'Low cal',
            'calories' => 200, // Below target
            'protein' => 15,
            'carbs' => 30,
            'fat' => 5,
            'fiber' => 5,
            'carbon_footprint' => 1.0,
        ]);

        Recipe::create([
            'name' => 'High Calorie Option',
            'description' => 'High cal',
            'calories' => 900, // Above target
            'protein' => 30,
            'carbs' => 100,
            'fat' => 40,
            'fiber' => 5,
            'carbon_footprint' => 3.0,
        ]);

        $response = $this->get('/recipes/smart-suggest');

        $response->assertStatus(200);
        $content = $response->getContent();
        $lowCalPos = strpos($content, 'Low Calorie Option');
        $highCalPos = strpos($content, 'High Calorie Option');
        
        // Low calorie option should rank higher
        $this->assertLessThan($highCalPos, $lowCalPos);
    }

    // Test 8: Current daily totals are calculated correctly
    public function test_current_daily_totals_calculated_correctly()
    {
        User::factory()->create(['id' => 1]);
        
        Goal::create([
            'user_id' => 1,
            'nutrient' => 'protein',
            'direction' => 'up',
            'target_value' => 100,
        ]);

        $recipe = Recipe::create([
            'name' => 'Test Recipe',
            'description' => 'Test',
            'calories' => 300,
            'protein' => 20,
            'carbs' => 40,
            'fat' => 10,
            'fiber' => 5,
            'carbon_footprint' => 2.0,
        ]);

        $today = now()->toDateString();
        
        // Add meal with 2 servings
        MealPlan::create([
            'user_id' => 1,
            'recipe_id' => $recipe->id,
            'date' => $today,
            'servings' => 2,
        ]);

        $response = $this->get('/recipes/smart-suggest');

        $response->assertStatus(200);
        // Should show 40 (20 protein * 2 servings) in the daily totals
        $response->assertSee('40');
    }

    // Test 9: Validation fails with invalid data
    public function test_add_from_suggestion_validates_data()
    {
        User::factory()->create(['id' => 1]);
        
        // Missing required fields
        $response = $this->post('/recipes/add-from-suggest', [
            'recipe_id' => 999, // Non-existent recipe
            'date' => 'invalid-date',
            'servings' => 0, // Invalid servings
        ]);

        $response->assertSessionHasErrors();
    }

    // Test 10: Helps-with tags are generated correctly
    public function test_helps_with_tags_generated_correctly()
    {
        User::factory()->create(['id' => 1]);
        
        Goal::create([
            'user_id' => 1,
            'nutrient' => 'protein',
            'direction' => 'up',
            'target_value' => 100,
        ]);

        Goal::create([
            'user_id' => 1,
            'nutrient' => 'fiber',
            'direction' => 'up',
            'target_value' => 30,
        ]);

        Recipe::create([
            'name' => 'Multi Goal Recipe',
            'description' => 'Helps multiple goals',
            'calories' => 300,
            'protein' => 40, // Helps protein goal
            'carbs' => 30,
            'fat' => 5,
            'fiber' => 15, // Helps fiber goal
            'carbon_footprint' => 2.0,
        ]);

        $response = $this->get('/recipes/smart-suggest');

        $response->assertStatus(200);
        $response->assertSee('protein');
        $response->assertSee('fiber');
    }
}

// tests/Unit/RecipeModelTest.php


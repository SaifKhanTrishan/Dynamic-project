<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\Recipe;

class RecipeTest extends TestCase
{
    use RefreshDatabase;

    public function test_recipes_page_loads()
    {
        Recipe::factory()->create(['name' => 'Test Recipe']);
        $response = $this->get('/recipes');
        $response->assertStatus(200);
        $response->assertSee('Test Recipe');
    }
}

<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Recipe;
use Illuminate\Foundation\Testing\RefreshDatabase;

class RecipeIndexTest extends TestCase
{
    use RefreshDatabase;

    public function test_recipe_index_displays_recipes()
    {
        Recipe::factory()->count(3)->create();

        $response = $this->get('/');

        $response->assertStatus(200);
        $response->assertViewHas('recipes');
    }
}

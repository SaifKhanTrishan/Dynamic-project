<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Meal Added</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #1CA9C9;
            color: #fff;
            margin: 0;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }

        .container {
            background: linear-gradient(135deg, #1CA9C9 0%, #0077B6 100%);
            padding: 50px;
            border-radius: 8px;
            text-align: center;
            max-width: 500px;
        }

        .container h1 {
            font-size: 32px;
            margin: 0 0 10px 0;
        }

        .container p {
            font-size: 16px;
            margin: 10px 0;
        }

        a {
            display: inline-block;
            background-color: #28a745;
            color: white;
            padding: 12px 24px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            margin-top: 20px;
        }

        a:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>✅ Meal Added Successfully!</h1>
    <p>Your meal has been added to your plan.</p>
    <a href="/">← Go Back to Recipes</a>
</div>

</body>
</html>
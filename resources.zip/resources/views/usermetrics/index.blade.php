<!-- resources/views/usermetrics/index.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Biometric Data</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #1CA9C9;
            color: #fff;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
        }

        .header {
            background: linear-gradient(135deg, #1CA9C9 0%, #0077B6 100%);
            padding: 30px;
            border-radius: 8px;
            margin-bottom: 30px;
        }

        .header h1 {
            margin: 0;
            font-size: 28px;
        }

        .nav-links {
            margin-bottom: 20px;
        }

        .nav-links a {
            display: inline-block;
            background-color: #0077B6;
            color: white;
            padding: 10px 20px;
            margin: 5px;
            border-radius: 6px;
            text-decoration: none;
        }

        .nav-links a:hover {
            background-color: #023E8A;
        }

        .btn {
            display: inline-block;
            background-color: #28a745;
            color: white;
            padding: 12px 24px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            margin-bottom: 20px;
        }

        .btn:hover {
            background-color: #218838;
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            border-left: 5px solid #28a745;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            color: #333;
            border-radius: 8px;
            overflow: hidden;
        }

        th {
            background-color: #0077B6;
            color: white;
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }

        td {
            padding: 12px 15px;
            border-bottom: 1px solid #e0e0e0;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        .delete-btn {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
        }

        .delete-btn:hover {
            background-color: #c82333;
        }

        .empty-message {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 30px;
            text-align: center;
            border-radius: 8px;
            margin: 20px 0;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1>📊 My Biometric Data</h1>
        <p>Track your health metrics over time</p>
    </div>

    <div class="nav-links">
        <a href="/">← Back to Recipes</a>
        <a href="/goals">📋 My Goals</a>
        <a href="/mealplans">📅 My Meals</a>
    </div>

    <!-- Success Message -->
    @if(session('success'))
        <div class="success-message">
            ✅ {{ session('success') }}
        </div>
    @endif

    <a href="/usermetrics/create" class="btn">➕ Record New Metric</a>

    @if($metrics->count() > 0)
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Weight (kg)</th>
                    <th>Blood Pressure</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($metrics as $metric)
                    <tr>
                        <td>{{ $metric->recorded_at->format('l, F j, Y') }}</td>
                        <td>{{ $metric->weight ?? '-' }}</td>
                        <td>{{ $metric->blood_pressure ?? '-' }}</td>
                        <td>
                            <form action="{{ route('usermetrics.destroy', $metric) }}" method="POST" style="display: inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="delete-btn" onclick="return confirm('Delete this metric?');">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @else
        <div class="empty-message">
            <p><strong>No biometric data yet!</strong></p>
            <p>Start tracking your weight and blood pressure to monitor your progress.</p>
            <a href="/usermetrics/create" class="btn" style="margin-top: 15px;">Record First Metric</a>
        </div>
    @endif
</div>

</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Record Biometric Data</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #1CA9C9;
            color: #fff;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
        }

        .header {
            background: linear-gradient(135deg, #1CA9C9 0%, #0077B6 100%);
            padding: 30px;
            border-radius: 8px;
            margin-bottom: 30px;
        }

        .header h1 {
            margin: 0;
            font-size: 28px;
        }

        .form-container {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            color: #333;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #333;
        }

        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            box-sizing: border-box;
        }

        input:focus {
            outline: none;
            border-color: #0077B6;
            box-shadow: 0 0 5px rgba(0, 119, 182, 0.3);
        }

        .button-group {
            display: flex;
            gap: 10px;
            margin-top: 30px;
        }

        button, .btn-cancel {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .btn-submit {
            background-color: #28a745;
            color: white;
        }

        .btn-submit:hover {
            background-color: #218838;
        }

        .btn-cancel {
            background-color: #6c757d;
            color: white;
        }

        .btn-cancel:hover {
            background-color: #5a6268;
        }

        .info-text {
            background-color: #e7f3ff;
            color: #0077B6;
            padding: 15px;
            border-radius: 6px;
            font-size: 14px;
            margin-top: 20px;
        }

        .error {
            color: #dc3545;
            font-size: 12px;
            margin-top: 5px;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1>📊 Record Biometric Data</h1>
        <p>Track your health metrics</p>
    </div>

    <div class="form-container">
        <form action="/usermetrics" method="POST">
            @csrf

            <div class="form-group">
                <label for="recorded_at">Date *</label>
                <input type="date" name="recorded_at" id="recorded_at" required 
                       value="{{ date('Y-m-d') }}">
                @error('recorded_at')
                    <div class="error">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group">
                <label for="weight">Weight (kg)</label>
                <input type="number" name="weight" id="weight" step="0.1" 
                       placeholder="e.g., 75.5">
                @error('weight')
                    <div class="error">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group">
                <label for="blood_pressure">Blood Pressure</label>
                <input type="text" name="blood_pressure" id="blood_pressure" 
                       placeholder="e.g., 120/80">
                @error('blood_pressure')
                    <div class="error">{{ $message }}</div>
                @enderror
            </div>

            <div class="info-text">
                <strong>Tips:</strong>
                <ul style="margin: 10px 0; padding-left: 20px;">
                    <li>Record measurements at the same time daily for consistency</li>
                    <li>Weight: measure after waking up, before eating</li>
                    <li>BP: measure after resting for 5 minutes</li>
                </ul>
            </div>

            <div class="button-group">
                <button type="submit" class="btn-submit">Save Metrics</button>
                <a href="/usermetrics" class="btn-cancel">Cancel</a>
            </div>
        </form>
    </div>
</div>

</body>
</html>
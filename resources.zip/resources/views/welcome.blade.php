<!DOCTYPE html>
<html>
<head>
    <title>Laravel is working</title>
    <style>
        body {
            font-family: sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background: #f5f5f5;
        }
    </style>
</head>
<body>
    <h1>Laravel is running successfully 🎉</h1>
    
</body>
</html>

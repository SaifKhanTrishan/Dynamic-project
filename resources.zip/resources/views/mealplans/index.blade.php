<!-- resources/views/mealplans/index.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Meal Plans</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #1CA9C9;
            color: #fff;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
        }

        .header {
            background: linear-gradient(135deg, #1CA9C9 0%, #0077B6 100%);
            padding: 30px;
            border-radius: 8px;
            margin-bottom: 30px;
        }

        .header h1 {
            margin: 0;
            font-size: 28px;
        }

        .nav-links {
            margin-bottom: 20px;
        }

        .nav-links a {
            display: inline-block;
            background-color: #0077B6;
            color: white;
            padding: 10px 20px;
            margin: 5px;
            border-radius: 6px;
            text-decoration: none;
        }

        .nav-links a:hover {
            background-color: #023E8A;
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            border-left: 5px solid #28a745;
        }

        .meal-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .meal-card {
            background-color: white;
            color: #333;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .meal-date {
            font-size: 12px;
            color: #666;
            font-weight: 600;
        }

        .meal-name {
            font-size: 18px;
            font-weight: 700;
            color: #1CA9C9;
            margin: 5px 0;
        }

        .meal-info {
            font-size: 13px;
            color: #555;
            margin: 8px 0;
        }

        .delete-btn {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            margin-top: 10px;
            width: 100%;
        }

        .delete-btn:hover {
            background-color: #c82333;
        }

        .empty-message {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 30px;
            text-align: center;
            border-radius: 8px;
            margin: 20px 0;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1>📅 My Meal Plans</h1>
        <p>Your scheduled meals</p>
    </div>

    <div class="nav-links">
        <a href="/">← Back to Recipes</a>
        <a href="/goals">📋 My Goals</a>
        <a href="/recipes/smart-suggest">💡 Get Suggestions</a>
    </div>

    <!-- Success Message -->
    @if(session('success'))
        <div class="success-message">
            ✅ {{ session('success') }}
        </div>
    @endif

    @if($plans->count() > 0)
        <div class="meal-grid">
            @foreach($plans as $plan)
                <div class="meal-card">
                    <div class="meal-date">📅 {{ $plan->date->format('l, F j, Y') }}</div>
                    <div class="meal-name">{{ $plan->recipe->name }}</div>
                    <div class="meal-info">
                        <strong>Servings:</strong> {{ $plan->servings }}<br>
                        <strong>Calories:</strong> {{ number_format($plan->recipe->calories * $plan->servings, 0) }} kcal<br>
                        <strong>Protein:</strong> {{ number_format($plan->recipe->protein * $plan->servings, 1) }}g<br>
                        <strong>Carbon:</strong> {{ number_format($plan->recipe->carbon_footprint * $plan->servings, 2) }} kg CO₂
                    </div>
                    <form action="{{ route('mealplans.destroy', $plan) }}" method="POST" style="margin: 0;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="delete-btn" onclick="return confirm('Remove this meal?');">Remove</button>
                    </form>
                </div>
            @endforeach
        </div>
    @else
        <div class="empty-message">
            <p><strong>No meals planned yet!</strong></p>
            <p>Go back to recipes and add meals to your plan.</p>
            <a href="/" style="color: white; text-decoration: underline;">Add Meals →</a>
        </div>
    @endif
</div>

</body>
</html>
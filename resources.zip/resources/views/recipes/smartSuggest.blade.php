<!-- resources/views/recipes/smartSuggest.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Recipe Suggestions</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #1CA9C9;
            color: #fff;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
        }

        .header-banner {
            background: linear-gradient(135deg, #1CA9C9 0%, #0077B6 100%);
            padding: 30px;
            border-radius: 8px;
            margin-bottom: 30px;
            text-align: center;
        }

        .header-banner h1 {
            margin: 0;
            font-size: 32px;
            font-weight: 700;
        }

        .header-banner p {
            margin: 10px 0 0 0;
            font-size: 14px;
            opacity: 0.9;
        }

        .nav-section {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 30px;
            text-align: center;
        }

        .nav-section a {
            display: inline-block;
            background-color: #0077B6;
            color: #fff;
            border: none;
            padding: 12px 20px;
            margin: 8px;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            font-size: 15px;
            font-weight: 500;
            transition: all 0.2s ease;
        }

        .nav-section a:hover {
            background-color: #023E8A;
            transform: translateY(-2px);
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            border-left: 5px solid #28a745;
        }

        .no-goals-message {
            background-color: #fff3cd;
            color: #856404;
            padding: 15px;
            border-radius: 6px;
            margin: 20px 0;
            border-left: 5px solid #ffc107;
        }

        .no-goals-message a {
            color: #856404;
            text-decoration: underline;
        }

        .goals-status {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 5px solid rgba(255, 255, 255, 0.3);
        }

        .goals-status h2 {
            margin-top: 0;
            font-size: 20px;
            margin-bottom: 15px;
        }

        .goal-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            background-color: rgba(255, 255, 255, 0.1);
            margin: 10px 0;
            border-radius: 6px;
            border-left: 4px solid rgba(255, 255, 255, 0.4);
            gap: 15px;
        }

        .goal-label {
            font-weight: 600;
            font-size: 14px;
            flex: 0 0 150px;
        }

        .goal-value {
            font-size: 16px;
            font-weight: 700;
            flex: 0 0 100px;
            text-align: right;
        }

        .progress-bar {
            flex-grow: 1;
            height: 20px;
            background-color: rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            overflow: hidden;
            min-width: 100px;
        }

        .progress-fill {
            height: 100%;
            background-color: #28a745;
            width: 0%;
            transition: width 0.3s ease;
        }

        .progress-fill.warning {
            background-color: #ffc107;
        }

        .progress-fill.danger {
            background-color: #dc3545;
        }

        .status-text {
            font-size: 12px;
            opacity: 0.8;
        }

        .nutrient-direction {
            font-size: 12px;
            opacity: 0.7;
            display: block;
            margin-top: 3px;
        }

        h2 {
            font-size: 24px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin: 30px 0 20px 0;
            text-align: center;
        }

        .suggestions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }

        .recipe-card {
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 15px;
            border-top: 4px solid rgba(255, 255, 255, 0.3);
            transition: all 0.2s ease;
        }

        .recipe-card:hover {
            background-color: rgba(255, 255, 255, 0.15);
            transform: translateY(-3px);
        }

        .recipe-title {
            font-size: 16px;
            font-weight: 700;
            margin: 0 0 10px 0;
        }

        .match-score {
            display: inline-block;
            background-color: #28a745;
            color: white;
            padding: 4px 8px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
            margin-bottom: 10px;
        }

        .helps-with {
            margin: 10px 0;
        }

        .helps-with-title {
            font-size: 11px;
            opacity: 0.8;
            display: block;
            margin-bottom: 5px;
        }

        .helps-tag {
            display: inline-block;
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 11px;
            margin: 3px 3px 3px 0;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .nutrition-info {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 10px;
            border-radius: 6px;
            font-size: 12px;
            margin: 10px 0;
        }

        .nutrition-row {
            display: flex;
            justify-content: space-between;
            padding: 4px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .nutrition-row:last-child {
            border-bottom: none;
        }

        .nutrition-label {
            font-weight: 600;
        }

        .nutrition-value {
            font-weight: 700;
        }

        .carbon-footprint {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 8px;
            border-radius: 6px;
            text-align: center;
            margin: 10px 0;
            font-size: 12px;
        }

        .carbon-label {
            opacity: 0.8;
            font-size: 11px;
        }

        .carbon-value {
            font-weight: 700;
            font-size: 16px;
            margin-top: 3px;
        }

        .add-recipe-form {
            margin-top: 15px;
            display: flex;
            gap: 5px;
            align-items: center;
        }

        .add-recipe-form input {
            padding: 8px;
            border: none;
            border-radius: 4px;
            font-size: 12px;
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
            flex: 1;
        }

        .add-recipe-form input::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }

        .add-recipe-form input::-webkit-calendar-picker-indicator {
            filter: invert(1);
        }

        .add-recipe-form button {
            background-color: #0077B6;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            font-size: 12px;
            transition: background-color 0.2s;
            white-space: nowrap;
        }

        .add-recipe-form button:hover {
            background-color: #023E8A;
        }

        .no-suggestions {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
            padding: 20px;
            text-align: center;
            border-radius: 8px;
            border-left: 5px solid rgba(255, 255, 255, 0.3);
        }

        .no-suggestions p {
            margin: 10px 0;
        }

        @media (max-width: 768px) {
            .goal-item {
                flex-wrap: wrap;
            }

            .goal-label {
                flex: 0 0 100%;
            }

            .progress-bar {
                flex: 0 0 100%;
                order: 3;
                margin: 10px 0 0 0;
            }

            .goal-value {
                flex: 0 0 auto;
            }

            .suggestions-grid {
                grid-template-columns: 1fr;
            }

            .add-recipe-form {
                flex-wrap: wrap;
            }

            .add-recipe-form input {
                min-width: 80px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <!-- Header -->
    <div class="header-banner">
        <h1>💡 Smart Recipe Suggestions</h1>
        <p>Personalized recommendations based on your daily goals</p>
    </div>

    <!-- Navigation -->
    <div class="nav-section">
        <a href="/">← Back to Recipes</a>
        <a href="/goals">📋 My Goals</a>
        <a href="/mealplans">📅 My Meals</a>
    </div>

    <!-- Success Message -->
    @if(session('success'))
        <div class="success-message">
            ✅ {{ session('success') }}
        </div>
    @endif

    <!-- No Goals Message -->
    @if(empty($goals) || count($goals) === 0)
        <div class="no-goals-message">
            <strong>⚠️ No Goals Set</strong><br>
            {{ $message ?? 'Create nutritional goals to get personalized recipe suggestions.' }}
            <br><a href="/goals">Create Goals Now →</a>
        </div>
    @else
        <!-- Goals Status Section -->
        <div class="goals-status">
            <h2 style="margin: 0 0 15px 0; text-align: left; font-size: 18px; text-transform: none; letter-spacing: 0;">Today's Progress</h2>

            @foreach($goals as $goal)
                @php
                    $current = $currentTotals[$goal->nutrient] ?? 0;
                    $target = $goal->target_value;
                    $direction = $goal->direction;
                    
                    if ($direction === 'up') {
                        $percentage = ($target > 0) ? min(($current / $target) * 100, 100) : 0;
                        $status = $current >= $target ? '✅ Goal met!' : '⏳ In progress';
                    } else {
                        $percentage = ($target > 0) ? max((($target - $current) / $target) * 100, 0) : 100;
                        $status = $current <= $target ? '✅ Within limit' : '⚠️ Over limit';
                    }
                @endphp

                <div class="goal-item">
                    <div class="goal-label">
                        {{ ucfirst(str_replace('_', ' ', $goal->nutrient)) }}
                        <span class="nutrient-direction">
                            @if($direction === 'up')
                                ↑ {{ number_format($target, 0) }}
                            @else
                                ↓ {{ number_format($target, 0) }}
                            @endif
                        </span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill {{ $percentage > 100 ? 'danger' : ($percentage > 75 ? 'warning' : '') }}" 
                             style="width: {{ min($percentage, 100) }}%;"></div>
                    </div>
                    <div class="goal-value">{{ number_format($current, 0) }}/{{ number_format($target, 0) }}</div>
                </div>
            @endforeach
        </div>
    @endif

    <!-- Suggestions Section -->
    <h2>Recommended Recipes</h2>

    @if(count($suggestions) > 0)
        <div class="suggestions-grid">
            @foreach($suggestions as $item)
                <div class="recipe-card">
                    <p class="recipe-title">{{ $item['recipe']->name }}</p>

                    <!-- Match Score -->
                    @if($item['score'] > 0)
                        <span class="match-score">{{ number_format($item['score'], 0) }}% Match</span>
                    @endif

                    <!-- Helps With -->
                    @if(count($item['helps_with']) > 0)
                        <div class="helps-with">
                            <span class="helps-with-title">Helps with:</span>
                            <div>
                                @foreach($item['helps_with'] as $goal)
                                    <span class="helps-tag">{{ $goal }}</span>
                                @endforeach
                            </div>
                        </div>
                    @endif

                    <!-- Nutrition Info -->
                    <div class="nutrition-info">
                        <div class="nutrition-row">
                            <span class="nutrition-label">Calories:</span>
                            <span class="nutrition-value">{{ number_format($item['recipe']->calories, 0) }}</span>
                        </div>
                        <div class="nutrition-row">
                            <span class="nutrition-label">Protein:</span>
                            <span class="nutrition-value">{{ number_format($item['recipe']->protein, 1) }}g</span>
                        </div>
                        <div class="nutrition-row">
                            <span class="nutrition-label">Carbs:</span>
                            <span class="nutrition-value">{{ number_format($item['recipe']->carbs, 1) }}g</span>
                        </div>
                        <div class="nutrition-row">
                            <span class="nutrition-label">Fat:</span>
                            <span class="nutrition-value">{{ number_format($item['recipe']->fat, 1) }}g</span>
                        </div>
                        <div class="nutrition-row">
                            <span class="nutrition-label">Fiber:</span>
                            <span class="nutrition-value">{{ number_format($item['recipe']->fiber, 1) }}g</span>
                        </div>
                    </div>

                    <!-- Carbon Footprint -->
                    <div class="carbon-footprint">
                        <div class="carbon-label">Carbon Footprint</div>
                        <div class="carbon-value">{{ number_format($item['recipe']->carbon_footprint, 2) }} kg CO₂</div>
                    </div>

                    <!-- Add to Meal Plan Form -->
                    <form action="{{ route('recipes.addFromSmartSuggest') }}" method="POST" class="add-recipe-form">
                        @csrf
                        <input type="hidden" name="recipe_id" value="{{ $item['recipe']->id }}">
                        <input type="date" name="date" value="{{ $today ?? date('Y-m-d') }}" required>
                        <input type="number" name="servings" value="1" min="1" max="10" placeholder="Servings">
                        <button type="submit">Add →</button>
                    </form>
                </div>
            @endforeach
        </div>
    @else
        @if(count($goals) > 0)
            <div class="no-suggestions">
                <p>No recipes available or all your goals are already met!</p>
                <p style="font-size: 12px;">Try adjusting your goals or adding more recipes.</p>
            </div>
        @endif
    @endif
</div>

</body>
</html>